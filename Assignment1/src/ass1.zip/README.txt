All you should have to do to run the game is run Game.java in the Game package.
WASD controls your movement. Arrow keys controls your weapon.

You start in the middle. The enemies are in red. Don't get eaten by them!
There are various powerups to collect that will change your weapon.