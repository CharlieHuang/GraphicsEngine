package ass1;

public class Powerup extends CircularGameObject {

	public Powerup(GameObject parent, double radius, double[] fillColour, double[] lineColour) {
		super(parent, radius, fillColour, lineColour);
	}
	
}
