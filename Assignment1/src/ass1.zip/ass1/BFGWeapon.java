package ass1;

public class BFGWeapon extends Powerup {
	
	public static final double[] weaponColour = {0.2,1,0.2,1};
	public BFGWeapon(GameObject parent, double radius,
			double[] fillColour, double[] lineColour) {
		super(parent, radius, fillColour, lineColour);
	}

}
