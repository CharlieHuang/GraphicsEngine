package ass1;

public class Aim {

}
