package ass1;

public enum Weapon {
	DEFAULT, PIERCING, SHOTGUN, BFG
}
